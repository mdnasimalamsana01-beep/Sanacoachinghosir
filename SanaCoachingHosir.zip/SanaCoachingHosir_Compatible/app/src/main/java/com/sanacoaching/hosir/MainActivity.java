package com.sanacoaching.hosir;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    int navy = Color.rgb(25,55,109);

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,247,251));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(16,18,16,18);
        header.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.sanacoaching.hosir.R.drawable.sana_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, new LinearLayout.LayoutParams(-1, 210));

        TextView title = text("SANA COACHING HOSIR", 24, true, navy);
        title.setGravity(Gravity.CENTER);
        header.addView(title);

        TextView sub = text("Learn Today, Lead Tomorrow", 15, false, Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        header.addView(sub);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(20,20,20,24);

        card(body, "📢 नवीनतम सूचना", "कोचिंग की महत्वपूर्ण सूचनाएँ यहाँ देखें।");
        card(body, "👨‍🎓 Students", "विद्यार्थियों से संबंधित जानकारी।");
        card(body, "📚 Classes & Subjects", "कक्षाओं और विषयों की जानकारी।");
        card(body, "📝 Homework / Study Material", "पढ़ाई की सामग्री और होमवर्क।");
        card(body, "💰 Fee Information", "फीस से संबंधित जानकारी और सूचना।");
        card(body, "📍 Coaching Location", "Sana Coaching Hosir");

        Button call = new Button(this);
        call.setText("☎️ 7079386852 पर कॉल करें");
        call.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:7079386852"))));
        body.addView(call, new LinearLayout.LayoutParams(-1,-2));

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    void card(LinearLayout parent, String title, String desc) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(24,20,24,20);
        c.setBackgroundColor(Color.WHITE);
        c.setElevation(4);

        TextView t = text(title,19,true,navy);
        TextView d = text(desc,15,false,Color.DKGRAY);
        d.setPadding(0,8,0,8);
        c.addView(t);
        c.addView(d);

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,0,0,16);
        parent.addView(c,p);
    }
}
